from collections import UserDict
class Field:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)

class Name(Field):
    def name(self, value):
        if value:
            self._name = value
        else:
            print("Enter a name, please")

class Phone(Field):
    def phone(self, value):
        if value.isdigit() and len(value) == 10:
            self._phone = value
        else:
            print("Filed should be 10 digits long.")

class Record:
    def __init__(self, name):
        self.name = Name(name)
        self.phones = []

    def add_phone(self, phone):
        self.phones.append(phone)

    def remove_phone(self, phone):
        if phone in self.phones:
            self.phones.remove(phone)
        else:
            print("Phone not found.")

    def edit_phone(self, old_phone, new_phone):
        if old_phone in self.phones:
            index = self.phones.index(old_phone)
            self.phones[index] = new_phone
        else:
            print("Phone not found.")

    def find_phone(self, phone):
        if phone in self.phones:
            return phone
        else:
            print(f"{phone} not found.")

    def __str__(self):
        return f"Contact name: {self.name.value}, phones: {'; '.join(p for p in self.phones)}"

class AddressBook(UserDict):
    def __init__(self):
        self.data = []

    def add_record(self, data):
        self.data.append(data)

    def find(self, name):
        found_records = [data for data in self.data if data.name.value == name]
        if found_records:
            print(f"Name {name} found:")
            for data in found_records:
                print(data.name, data.phones)
            return data
        else:
            print(f"I searched {name} but didn't find.")
            return None

    def delete(self, name):
        removed = False
        for record in self.data:
            if record.name.value == name:
                self.data.remove(record)
                removed = True
        if removed:
            print(f"Deleted {name} from address book.")
        else:
            print(f"{name} wasn't found.")

    def display_all_records(self):
        print("All items in list:")
        for record in self.data:
            print(record.name, record.phones)

book = AddressBook()

# Створення запису для John
john_record = Record("John")
john_record.add_phone("1234567890")
john_record.add_phone("5555555555")

# Додавання запису John до адресної книги
book.add_record(john_record)

# Створення та додавання нового запису для Jane
jane_record = Record("Jane")
jane_record.add_phone("9876543210")
book.add_record(jane_record)

# Виведення всіх записів у книзі
book.display_all_records()

# Знаходження та редагування телефону для John
john = book.find("John")
john.edit_phone("1234567890", "1112223333")

print(john)  # Виведення: Contact name: John, phones: 1112223333; 5555555555

# Пошук конкретного телефону у записі John
found_phone = john.find_phone("5555555555")
print(f"{john.name}: {found_phone}")  # Виведення: 5555555555

# Видалення запису Jane
book.delete("Jane")

#-------------------BOT-------------------
def input_error(func):
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError:
            return "Give me name and phone please."
        except KeyError:
            return "Something went wrong"
        except IndexError:
            return "Incorrect index. Try again"

    return inner

def parse_input(user_input):
    while not user_input:
        print("Empty command. Try again.")
        user_input = input("Enter a command: ")
    cmd, *args = user_input.split()
    cmd = cmd.strip().lower()
    return cmd, *args

@input_error
def add_contact(args, contacts):
    name, phone = args
    if name in contacts:
        return f"Contact already exists! If you want to update phone - use [change {name} NEW_PHONE] command"
    else:
        contacts[name] = phone
        return "Contact added."

@input_error
def change_contact(args, contacts):
    name, phone = args
    if name in contacts:
        contacts[name] = phone
        return f"Contact changed to {name}: {contacts[name]}"
    else:
        return "Contact not found"  

@input_error
def show_phone(args, contacts):
    name, *phone = args
    if name in contacts:
        return contacts[name]
    else:
        return "Contact not found."   

@input_error
def all(contacts):
    for name, phone in contacts.items():
        print ("Name: {:<7} | Phone: {:<7} | ".format(name, phone))

def help():
    commands = ["hello/hi", "add", "change", "find", "all", "close/exit"]
    description = ["N/A", "Name and Phone", "Name and Phone", "Name", "N/A", "N/A"]
    print ('| {:1} | {:^14} | {:^14} | {:^5} | {:^3} | {:^3} |'.format(*commands))
    print ('| {:^8} | {:^11} | {:^11} | {:^5} | {:^3} | {:^10} |'.format(*description))

def main():
    contacts = {}
    print("Welcome to the assistant bot! Use HELP to see all commands")
    while True:
        user_input = input("Enter a command: ")
        command, *args = parse_input(user_input)

        if command in ["close", "exit"]:
            print("Good bye!")
            break
        elif command in ["hello", "hi"]:
            print("How can I help you?")
        elif command == "add":
            print(add_contact(args, contacts))
        elif command == "change":
            print(change_contact(args, contacts))
        elif command == "find":
            print(show_phone(args, contacts))
        elif command == "all":
            all(contacts)
        elif command == "help":
            help()                  
        else:
            print("Invalid command.")

main()
